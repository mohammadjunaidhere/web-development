import "./App.css";
import Main from "./Components/Main";

function App() {
  return (
    <div className="App">
    
      <header></header>
      <Main />
    </div>
  );
}

export default App;
