import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Navbar from "./components/Navbar";
import Homescreen from "./screens/Homescreen";
import Bookingscreen from "./screens/Bookingscreen";
import Signinscreen from "./screens/Signinscreen";
import Signupscreen from "./screens/Signupscreen";
import Profilescreen from "./screens/Profilescreen";
import Adminscreen from "./screens/Adminscreen";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <Navbar />
        <Routes>
          <Route path="/" exact element={<Homescreen />} />
          <Route path="/booking/:roomid/:fromDate/:toDate" exact element={<Bookingscreen />} />
          <Route path="/user/signup"  element={<Signupscreen />} />
          <Route path="/user/signin"  element={<Signinscreen />} />
          <Route path="/user/profile" element={<Profilescreen />} /> 
          <Route path="/user/admin" element={<Adminscreen />} /> 
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
