export const BASE_URL = "https://hotel-booking-backend.netlify.app/.netlify/functions"
// export const BASE_URL = "http://localhost:9000/.netlify/functions"